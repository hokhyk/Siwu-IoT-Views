import BigScreenComponentMag from './index.vue'

BigScreenComponentMag.install = function (Vue) {
  Vue.component(BigScreenComponentMag.name, BigScreenComponentMag)
}

export default BigScreenComponentMag
