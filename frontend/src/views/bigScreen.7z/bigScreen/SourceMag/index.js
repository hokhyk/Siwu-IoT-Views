import BgiScreenSourceMag from './index.vue'

BgiScreenSourceMag.install = function (Vue) {
  Vue.component(BgiScreenSourceMag.name, BgiScreenSourceMag)
}

export default BgiScreenSourceMag
