import BigScreenManagement from './index.vue'

BigScreenManagement.install = function (Vue) {
  Vue.component(BigScreenManagement.name, BigScreenManagement)
}

export default BigScreenManagement
